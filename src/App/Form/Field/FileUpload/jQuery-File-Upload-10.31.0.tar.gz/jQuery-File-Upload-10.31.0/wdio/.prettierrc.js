'use strict'

module.exports = {
  arrowParens: 'avoid',
  proseWrap: 'always',
  semi: false,
  singleQuote: true,
  trailingComma: 'none'
}
